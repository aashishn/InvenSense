@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/adf/svc/types/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.invensense.ws.fusion.stubs.userdetails;
